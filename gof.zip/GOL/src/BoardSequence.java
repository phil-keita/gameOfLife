import java.util.ArrayList;

public class BoardSequence {
	
	private Board currentBoard; // contains the current board
	private ArrayList<Board> boards;// records the different generation boards
	
	/**
	 * Creates a BaordSequence object. Initializes the current Board and add it as generation 0
	 * in the list of boards
	 * @param startingBoard: the starting board
	 */
	BoardSequence (Board startingBoard){
		currentBoard = startingBoard;
		boards = new ArrayList<Board>();
		boards.add(startingBoard);
	}
	
	/**
	 *  Uses nextBoard() method to generate the next generation 
	 *  and sets currentBoard as the new board generated
	 *  Adds the new currentBoard to the list 
	 * @param numSteps: The number of generations to run
	 */
	public void runMoreSteps(int numSteps) {
		for (int i = 0; i < numSteps; i++) {
			currentBoard = currentBoard.nextBoard();
			boards.add(currentBoard);
		}
	}
	
	/**
	 *  Returns the board at a  certain generation indicated
	 * @param index: the index of the generation wanted to be returned
	 * @return the board at the indicated generation
	 * @throws IllegalArgumentException
	 */
	public Board boardAt(int index) throws IllegalArgumentException{
		if(index < 0 || index >= boards.size()) {
			throw new IllegalArgumentException("This is not a valid generation");
		}
		return boards.get(index);
	}
	
	/**
	 * Prints Every generation yet generated
	 */
	public String toString() {
		String string = "";
		try {
			for (int i = 0; i < boards.size(); i++) {
			string += "Generation " + i + "\n" +  boardAt(i).toString() + "\n";
			
		}
		return string;
		}
		catch (Exception e){
			return e.getMessage();
		}
		
	}
	
	/**
	 * Finds a cycle in the generations generated
	 * @return returns the generation number at which is found a cycle or -1 if there is no cycle
	 * @throws Exception
	 */
	public int findCycle() throws Exception{
		for (int i = 0; i < boards.size(); i++) {
			for (int j = i + 1; j < boards.size(); j ++) {
				if (boards.get(i).isSame(boards.get(j))){
					return j;
				}
			}
		}
		return -1;
	}
	
	/**
	 * Checks if there is a cycle in the board generated
	 * @return false if there is no cycle and true if there is.
	 * @throws Exception
	 */
	boolean hasCycle() throws Exception{
		if (findCycle() != -1) {
			return true;
		}
		else {
			return false;
		}
	}
}
