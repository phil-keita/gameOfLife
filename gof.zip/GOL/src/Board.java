import java.util.Scanner;

/**
 * 
 * @author TODO: Philippe Keita
 * A snapshot of a Game of Life board at one point in time
 */
public class Board {
	// Declaring constants to facilitate the code readability
	private final boolean DEAD = false;
	private final boolean ALIVE = true;

	// The two-dimensional grid of board cells.
	// cells[r][c] is true if the cell at row r and column c is alive.
	private boolean[][] cells;

	//The grid dimensions
	private int numRows;
	private int numCols;

	
	/**
	 * Creates a Board with no live cells
	 * @param numberOfRows - number of rows in the board
	 * @param numberOfColumns - number of columns in the board
	 */
	public Board(int numberOfRows, int numberOfColumns){
		// TODO: complete this method
		numRows = numberOfRows;
		numCols = numberOfColumns;
		// Creating the array
		cells = new boolean[numRows][numCols];
		// Filling the array with dead cells
		for (int row = 0; row < numRows; row++) {
			for (int col = 0; col < numCols; col++ ) {
				cells[row][col] = DEAD;
			}
		}
	}
	
	
	/**
	 * Constructs a Board from the given String.
	 * @param boardInfo: A String in the format specified in the instructions under "File Format"
	 *     The string should contain all of the lines, so it will have newlines in it.
	 * Example:
"Glider\n" +
"7\n" +
"8\n" +
"        \n" +
"  X     \n" +
"   X    \n" +
" XXX    \n" +
"        \n" +
"        \n" +
"        \n"
	 */
	public Board(String boardInfo){
		// TODO: complete this method
		
		Scanner scan = new Scanner(boardInfo);
		scan.useDelimiter("\n");
		
		scan.next(); // grabbing the first line which is the name
		numRows = scan.nextInt();
		numCols = scan.nextInt();
		
		// Creating a new grid for cells
		cells = new boolean[numRows][numCols];
		// Setting all cells to be dead
		for (int row = 0; row < numRows; row++) {
			for (int col = 0; col < numCols; col++ ) {
				cells[row][col] = DEAD;
			}
		}
		// For each line we grab each character; if it is a space the cell is DEAD;
		// if it is an X the cell is ALIVE
		for (int row = 0; row < numRows; row ++) {
			if(scan.hasNext()) {
				String line = scan.next();
				for (int col = 0; col < numCols; col ++) {
					if (line.charAt(col) == ' '){
						cells[row][col] = DEAD;
					}
					else if (line.charAt(col) == 'X') {
						cells[row][col] = ALIVE;
					}

				}
			}
			else {
				break; // We want to exit the loop if the file contains no more lines
			}
		}
		scan.close();
	}

	
	/**
	 * @return number of rows in the board
	 */
	public int getNumRows(){
		// TODO: complete this method
		return numRows;
	}
	
	/**
	 * @return number of columns in this board
	 */
	public int getNumCols(){
		// TODO: complete this method
		return numCols;
	}
	
	/**
	 * @return value of the cell at the given @param row and @param col
	 * @throws IllegalArgumentException if row or col is out of bounds.
	 */
	public boolean getCell(int row, int col) throws IllegalArgumentException{
		// TODO: complete this method
		if(row > numRows - 1 || col > numCols - 1 || row < 0 || col  < 0) {
			throw new IllegalArgumentException ("This is not a valid cell case");
		}
		return cells[row][col];
	}
	
	/**
	 * Counts the number of alive neighbors of a cell.
	 * @param row: row of the cell to count neighbors of 
	 * @param col: column of the cell to count neighbors of 
	 * @return numAliveNeigbors: The number of alive neighbors of the cell at cells[row][col]
	 */
	public int numAliveNeighbors(int row, int col) {
		int numAliveNeighbors = 0;
		
		// Checks for the 3 neighbors on the row on top of cells and on the bottom of the cell
		for (int i = 0; i < 3; i ++) {
			// Bottom
			if (cells[row - 1][col + i - 1] == ALIVE) {
				numAliveNeighbors++;
			}
			//Top
			if (cells[row + 1][col + i - 1] == ALIVE) {
				numAliveNeighbors++;
			}
		}
		
		// Checks for the neighbors on the side of the cell
		//Left side
		if (cells[row][col - 1] == ALIVE) {
			numAliveNeighbors++;
		}
		//Right side
		if (cells[row][col + 1] == ALIVE) {
			numAliveNeighbors++;
		}	
		return numAliveNeighbors;
	}
	
	
	/**
	 * @return A new Board for the next generation (i.e., after this).
	 *    at the next time slice.
	 *    The cell values for the next generation
	 *    are determined by the rules of Game of Life.
	 */
	public Board nextBoard(){
		// TODO: complete this method
		Board nextBoard = new Board(numRows, numCols); //Creates the next board
		
		//Looping from row = 1 to numRows - 1  and from col = 1 to numCols - 1 because the border cells are 
		//always dead. 
		for (int row = 1; row < numRows - 1; row++) { 
			for (int col = 1; col < numCols - 1; col++) {
				// Applying the rules of living cells
				if (this.cells[row][col] == ALIVE) {
					if(this.numAliveNeighbors(row, col) < 2) {
						nextBoard.cells[row][col] = DEAD;
					}
					else if(this.numAliveNeighbors(row, col) < 4) {
						nextBoard.cells[row][col] = ALIVE;
					}
					else {
						nextBoard.cells[row][col] = DEAD;
					}
				}
				// Applying the rules of dead cells
				else {
					if(this.numAliveNeighbors(row, col) == 3) {
						nextBoard.cells[row][col] = ALIVE;
					}
				}
			}
		}
		
		return nextBoard;
	}
	

	/**
	 * @return true if other is the same size as this board
	 *   AND all of the cells of other have the same
	 *   values as the cells in this board
	 */
	public boolean isSame(final Board other) throws Exception{
		// TODO: complete this method
		// If the two boards do not have same size they are not equal
		if ((this.numRows != other.getNumRows()) || (this.numCols != other.getNumCols())) {
			return false;
		}
		// If they have same size we check for each cell
		else {
			for (int row = 0; row < numRows; row++) {
				for (int col = 0; col < numCols; col++) {
					if (cells[row][col] != other.getCell(row, col)) {
						return false;
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * @return a String representation of the current board state
	 * Example:
	 *    ......\n
	 *    ......\n
	 *    .X....\n
	 *    ..X...\n
	 *    .XX...\n
	 *    ......\n
	 *    
	 *    Each row of the board should be printed on its own line.
	 *    The \n above represents a newline 
	 *    (which will not appear when the string is printed).
	 *    . characters are for dead cells.
	 *    X characters are for live cells.
	 *    The String should end with a newline.
	 */
	@Override
	public String toString(){
		// TODO: complete this method
		String grid = "";
		for (int row = 0; row < numRows; row++) {
			for (int col = 0; col < numCols; col++) {
				if(cells[row][col] == ALIVE) {
					grid = grid + "X";
				}
				else {
					grid = grid + ".";
				}
			}
			grid = grid + "\n";
		}
		return grid;
	}
	
	

}
