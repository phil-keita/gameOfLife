import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class GameOfLife {
	public static void main(String[] args) throws Exception{
		//Declaration part
		Scanner scn = new Scanner(System.in);
		String inputFileName; 
		String outputFileName;
		int numGenerations;

		//Prompting to type the input file name
		System.out.println("Enter the starting board file: ");
		inputFileName = scn.next();

		//Prompting to enter the number of generations
		System.out.println("Enter the number of generations: ");
		numGenerations = scn.nextInt();

		// Prompting to enter the output File
		System.out.println("Enter the output file: ");
		outputFileName = scn.next();

		//Creating the output file and print writer
		File outputFile = new File(outputFileName);
		PrintWriter pen = new PrintWriter(outputFile);

		// Creating a new board object with the content of the input file
		Board startingBoard = new Board(readFileContents(inputFileName));
		//Printing the starting board
		System.out.println(startingBoard.toString());

		//Creating a sequence and running the number of steps
		BoardSequence gofSequence = new BoardSequence(startingBoard);
		gofSequence.runMoreSteps(numGenerations);
		pen.print(gofSequence.toString());

		//Printing the eventual cycle
		if (gofSequence.hasCycle()) {
			System.out.println("Cycle detected on generation " + gofSequence.findCycle());
		}
		else {
			System.out.println("No cycles detected.");
		}

		pen.close();
	}

	/**
	 * Reads from an input file and copying the content line by line to 
	 * a string that is returned by the method
	 * @param filename: name of the input file
	 * @return String fileContent: The string with the content of the input file
	 * @throws FileNotFoundException
	 */
	public static String readFileContents(String filename) throws FileNotFoundException{

		//Creating input file and scanner
		File inputFile = new File(filename);
		Scanner scan = new Scanner(inputFile);

		//Reading file and copying it to the string to return
		String fileContent = "";
		while (scan.hasNext()) {
			fileContent += scan.nextLine() + "\n";
		}
		scan.close();
		return fileContent;
	}
}
